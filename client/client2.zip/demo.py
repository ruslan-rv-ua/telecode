import os
import subprocess
from datetime import datetime
from pathlib import Path
from time import sleep
from urllib.request import urlopen
from winsound import Beep

REMOTE_FILE = "http://ruslanrvua.hopto.org:8003/learn_code.py"
LOCAL_FILE_NAME = "program"

REFRESH_TIME = 3  # seconds
WAIT_AFTER_ERROR_TIME = 5  # seconds

BEEPS_OK = [(fraq, 30) for fraq in (440, 880)]
BEEPS_ERROR = [(fraq, 500) for fraq in (1000, 1000, 1000)]
BEEPS_GETTING = [(fraq, 20) for fraq in (300, 600, 1200, 2400)]

EDITOR_TEXT_AT_STARTUP = "Очікуємо з'єднання з сервером"

CURR_DIR = Path(__file__).parent
editor_path = CURR_DIR / "Notepad++" / "notepad++.exe"


clear_screen = lambda: os.system("cls")


def get_local_file_path(add_timestamp=False):
    if add_timestamp:
        timestamp = datetime.now().strftime("_%H_%M_%S")
        full_file_name = LOCAL_FILE_NAME + timestamp + ".py"
    else:
        full_file_name = LOCAL_FILE_NAME + ".py"
    local_file_path = CURR_DIR / full_file_name
    return local_file_path


def make_sound_notification(beeps):
    for freq, dur in beeps:
        Beep(freq, dur)


def get_remote_file():
    try:
        with urlopen(REMOTE_FILE) as response:
            data = response.read()
    except Exception as e:
        # print(e)
        return
    return data


def save_data(local_file_path, data):
    try:
        with open(local_file_path, "wb") as file:
            file.write(data)
    except Exception as e:
        return
    return local_file_path


def save_text(local_file_path, text):
    try:
        local_file_path.write_text(text, encoding="utf-8")
    except Exception as e:
        return
    return local_file_path


local_file_path = get_local_file_path()
save_text(local_file_path, EDITOR_TEXT_AT_STARTUP)
try:
    subprocess.Popen([str(editor_path), str(local_file_path)])
except Exception as e:
    # print(e)
    pass

last_content = None
retrieves = 0
show_getting_msg = True

while True:
    if show_getting_msg:
        make_sound_notification(BEEPS_GETTING)
        clear_screen()
        print("Отримуємо дані з сервера...")
        show_getting_msg = False
    content = get_remote_file()
    if content is None:
        print(
            f"Не вдалось отримати дані з сервера. Наступна спроба через {WAIT_AFTER_ERROR_TIME} секунд."
        )
        make_sound_notification(BEEPS_ERROR)
        last_content = None
        retrieves = 0
        sleep(WAIT_AFTER_ERROR_TIME)
        show_getting_msg = True
        continue
    if content != last_content:
        file_path = save_data(get_local_file_path(), content)
        if not file_path:
            print("Не вдалось зберегти локальний файл")
            make_sound_notification(BEEPS_ERROR)
            input("Натисніть клавішу <Enter>")
            exit()
        save_data(get_local_file_path(add_timestamp=True), content)
        clear_screen()
        make_sound_notification(BEEPS_OK)
        print("Локальний файл збережено")
        print(file_path.absolute())
        last_content = content
        retrieves = 0
    else:
        retrieves += 1
        print(f"\rОновлено {retrieves*REFRESH_TIME} секунд тому ", end="", flush=True)
    sleep(REFRESH_TIME)
